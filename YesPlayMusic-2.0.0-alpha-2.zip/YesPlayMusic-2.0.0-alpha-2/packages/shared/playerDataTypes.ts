export enum RepeatMode {
  Off = 'off',
  On = 'on',
  One = 'one',
}

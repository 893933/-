import Artist from './Artist'

export default Artist

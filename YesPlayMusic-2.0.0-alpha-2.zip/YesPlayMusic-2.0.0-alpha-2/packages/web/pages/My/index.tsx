import My from './My'

export default My

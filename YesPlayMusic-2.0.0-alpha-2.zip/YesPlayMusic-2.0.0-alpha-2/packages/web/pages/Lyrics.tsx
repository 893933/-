const Lyrics = () => {
  return <div className='text-white'>歌词页面开发中</div>
}

export default Lyrics

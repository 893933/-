import Album from './Album'
export default Album

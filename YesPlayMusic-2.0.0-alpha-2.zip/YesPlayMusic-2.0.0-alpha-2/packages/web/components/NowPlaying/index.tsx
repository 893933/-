import NowPlaying from './NowPlaying'

export default NowPlaying

function Tooltip() {
  return <></>
}

export default Tooltip
